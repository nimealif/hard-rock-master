# hard-rock-solution
### Search Song
api link: https://api.lyrics.ovh/suggest/:searchText

example: https://api.lyrics.ovh/suggest/hello

### Lyric
lyric link: https://api.lyrics.ovh/v1/:artist/:title

example: https://api.lyrics.ovh/v1/Adele/Hello
